#include<stdio.h>
struct book{
    char title[100];
    char author[100];
    int price;
};

int main()
{
    struct books b1,b2,b3,b4,b5;
    b1.title='The Retreat';
    b2.title='Krishna Deva Raya';
    b3.title='The novels of sherlock holmes';

    b1.author='Sarah Pearse';
    b2.author='Abhijeet Hiliyana';
    b3.author='Conan Doyle';

    b1.price=196;
    b2.price=356;
    b3.price=298;
    ;

    printf("books in arranging order;");
    if (b1.price>b2.price)
    {
        print("book name=%c,book author=%c",b1.title,b1.author);
    }

    else if (b2.price>b3.price)
    {
         print("book name=%c,book author=%c",b2.title,b2.author);
    }

    else{
         print("book name=%c,book author=%c",b3.title,b3.author);
    }
    
    return 0;

}