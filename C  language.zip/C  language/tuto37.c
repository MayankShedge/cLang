#include<stdio.h>
struct student
{
    int id ;
    int marks;
    char fav_char;
    char name[34];
};

int main()
{
   struct student Mayank,Yash,Dhruv;
   {
       Mayank.id=1;
       Yash.id=2;
       Dhruv.id=3;
       Mayank.marks=567;
       Yash.marks=581;
       Dhruv.marks=485;
       Mayank.fav_char='a';
       Yash.fav_char='b';
       Dhruv.fav_char='c';
       printf("Mayank got %d marks\n",Mayank.marks);
   };
    
    return 0;
}