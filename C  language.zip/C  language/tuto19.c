#include<stdio.h>

int main() 
{ 
	int a=23;
	float b= (float)54/7;
	printf("the value of b is\n %f\n and %d\n",b,a); 
	
	return 0; 
}