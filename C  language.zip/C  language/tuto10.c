#include <stdio.h>
int main()
{
    int age;
    printf("enter your age\n");
    scanf("%d", &age);
    printf("you have entered %d as your age\n",age);

    if (age>=18)
    {
        printf("you can vote\n");
    }

    else if (age<10)
    {
        printf("\n fuck off doodh ka daat bhi nahi tuta chutiye jake padhai kar");
    }
    

    else
    {
        printf("\nyou cannot vote");
    }
    
    return 0;
    
}