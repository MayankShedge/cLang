#include<stdio.h>
  void starpattern(int row)
  {
      for (int i = 0; i < row; i++)
      {
       
       for (int j = 0; j <= i; j++)
       {
           printf("*");
       }
       
        printf("\n");
      }
      
  }

  void REVERSEstarpattern(int row)
  {
      for (int i = 0; i < row; i++)
      {
       
       for (int j = 0; j <=row -i-1; j++)
       {
           printf("*");
       }
       
        printf("\n");
      }
      
  }


int main()
{
   int row,type;
   printf("enter 0 for star pattern and 1 for reversed pattern\n");
   printf("enter the number of rows\n ");
   scanf("%d", &row);
   scanf("%d",&type);
   switch (type)
   {
   case 0:
       starpattern(row);
       break;
   
   default:
           REVERSEstarpattern(row);
       break;
   }
    
    return 0;
}