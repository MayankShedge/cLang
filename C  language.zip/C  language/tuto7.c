#include <stdio.h>
int main()
{
    int a,b;
    
    a=35;
    b=4;

    printf("a+b = %d\n",a+b);
    printf("a-b = %d\n",a-b);
    printf("a*b = %d\n",a*b);
    printf("a/b = %d\n",a/b);

    return 0;

}