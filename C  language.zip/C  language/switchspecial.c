#include <stdio.h>
int main()
{
    char op;
    int a, b, c;
    printf("enter the operator\n");
    scanf("%c", &op);
    printf("enter th 2 numbers\n");
    scanf("%d %d", &a, &b);

    switch (op)
    {
    case '+':
        c = a + b;
        printf("%d+%d=%d", a, b, c);
        break;

    case '-':
        c = a - b;
        printf("%d-%d=%d", a, b, c);
        break;

    case '*':
        c = a * b;
        printf("%d*%d=%d", a, b, c);
        break;

    case '/':
        c = a / b;
        printf("%d/%d=%d", a, b, c);
        break;

    default:
        printf("enter a valid operator");
        break;
    }
    return 0;
}
