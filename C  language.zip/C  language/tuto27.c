#include<stdio.h>

int main()
{
   /* char a='45';
    char* ptra= &a;
   
    printf("the adress of a is %d\n", ptra);
    printf("the adress of a is %d\n", ptra);
    ptra--;
    printf("the adress of a is %d\n", ptra+3);*/

    int arr[] = {1,2,3,4,5,9};
    int* ptr= arr;
    printf(" value of array at position 1 is %d\n", arr[0]);
    printf(" value of array at position 1 is %d\n", arr + 0);
    printf("the address of first element of array is %x\n", &arr[0]); 
    printf("the address of third element of array is %x\n", &arr[2]); 
    printf("the address of third element of array is %x\n", &arr + 2);
    printf(" value of array at position 3 is %d\n", arr[2]);
    printf(" value of array at position 3 is %d\n", arr + 2);
    printf(" value of array at position 3 is %d\n", *(&arr[2]));
    //arr++;THIS LINE WILL CAUSE ERROR AS ARR IS A CONSTANT//

    return 0;
}