#include<stdio.h>
int fib(int n)
{
    if (n==0)
    {
        return 0;
    }
    

    else if (n==1)
    {
        return 1;
    }
    
    else{
        return fib(n-1)+fib(n-2);
    }
}
 int main()
 {
  int n,ans;
  printf("enter the number of terms you want");
  scanf("%d",&n);
  ans=fib(n);
  printf("the fiboacci series is:-\n %d\n",ans);
  return 0;
 }

