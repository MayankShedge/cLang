#include<stdio.h>
int main()
{
    int y;
    printf("enter the year");
    scanf("%d",&y);
    if (y>1 && y<9999)
    {
        if ((y%4==0) && (y%100!=0) || (y%400==100))
        {
            printf("%d is a leap year",y);
        }
        
        else{
            printf("%d is not a leap year",y);
        }
    }
    
    else{
        printf("error 404");
    }
    return 0;
}