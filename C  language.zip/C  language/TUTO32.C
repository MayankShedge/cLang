  *(ptr + 2) = 95;

}

void func3(int* arr[2][2])
{
    for (int i = 0; i < 2; i++)
    {#include<stdio.h>
int func1(int arr[])
{
    for (int i = 0; i < 4; i++)
    {
        printf("the value at %d is %d\n",i,arr[i]);
    }
    arr[0]=99;//this point is very important if you change any value here it will be change in int main() funtion(gets reflected in int main).
    
}

int func2(int* ptr)
{
    for (int i = 0; i < 4; i++)
    {
        printf("the value at %d is %d\n",i,*(ptr+i));
        return 0;
    }
        for (int j = 0; j < 2; j++)
        {
            printf("The value at %d, %d is %d\n", i, j, arr[i][j]);
        }
    }
}

int main()
{
    int arr[]={23,54,10,55};
    /*printf("the value at index 0 id %d\n", arr[0]);
    func1(arr);
    printf("the value at index 0 id %d\n", arr[0]);*/
   /* func2(arr);
    func2(arr);*/
    func3(arr);
    
    return 0;
}



   

    
    
