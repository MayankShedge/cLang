#include<stdio.h>
int main()
{
    int a[3][3]; 
    printf("the matrix is:-\n");
    for (int i = 0; i < 3; i++)
    {
       
        for (int j = 0; j < 3; j++)
        {
            printf("the elements of matrix are [%d][%d]\n",i,j);
            scanf("%d",&a[i][j]);
        }
        
    }
    
    for (int i = 0; i < 3; i++)
    {
        
        for (int j = 0; j < 3; j++)
        {
            a[i][j]=a[j][i];
        }
        
    }

     printf("the transpose of matrix is");
    for (int i = 0; i < 3; i++)
    {
        
        for (int j = 0; j < 3; j++)
        {
           printf("%d",a[j][i]);
        }
        
    }
    
    return 0;

}