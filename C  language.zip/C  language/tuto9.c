#include<stdio.h>
#define PI 3.14
int main()
{
    int a=6;
   const float b=8.33;


   printf("%f\n",PI);

    printf("\nthe value of a is %d \t\t\t value of b is %9.6f\n",a,b);

    return 0;
}