#include <stdio.h>
struct student 
{
    int id ;
    int marks;
    char fav_char;
    char name[34];
};

int main()
{
     struct student s1,s2,s3;
     s1.id=21;
     s2.id=32;
     s3.id=45;
    // typedef <previous_name> <alias_name>;
    /*typedef unsigned long ul;
    ul l1, l2, l3;*/
    printf()
    return 0;
}