#include<stdio.h>

/*int sum(int a, int b)

    {
    return a+b;
    }*/
    

   void printstar (int n)
   {
   for (int i = 0; i < n; i++)
   {
       printf("%c", '*');
   }

}
   

   /* int takenumber()
    {
        int i;
        printf("\n enter a number");
        scanf("%d", &i);
        return i;
    }*/
    

    int main()
    {
    
        /*int a,b,c;
       a=7;
        b=15;
        c=sum(a,b);
        //d=takenumber();*/
        

        printstar(9);
        

        //printf("the sum is %d\n", c);
       // printf("the number entered is %d\n", d);
        return 0;
    }
    



    


















