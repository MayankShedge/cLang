#include<stdio.h>
int main()
{
    float arr[100];
    int n,i;
    printf("enter the number of elements");
    scanf("%d",&n);
    printf("enter the elements of array");
    for (int i = 0; i < n; i++)
    {
        printf("the elements are:- %d",i);
        scanf("%f",&arr[i]);
    }

    for (int i = 1; i < n; i++)
    {
        if (arr[0]<arr[i])
        {
            arr[i]=arr[0];
        }
    }

    printf("the largest element is %f",arr[0]);
    return 0;
}