#include<stdio.h>
void arrayRev(arg1)
{
   


}

int main()
{
  int arr[7]={1,2,3,4,5,6,54};
  arrayRev(arr);
  printf("the array is ", arr);
}