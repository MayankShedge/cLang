#include<stdio.h>
#include<stdlib.h>
int main()
{
    char ptr;
    int n;
    //using malloc to allocate id
    printf("Enter the no of employees you want\n");
    scanf("%d",&n);
    ptr=(int*)malloc(sizeof(int));
    for (int i = 0; i < n; i++)
    {
        printf("enter the id of employee\n");
        scanf("%s",ptr[i]);
    }
    
    for (int i = 0; i < n; i++)
    {
        printf("The id of employee is %s\n",ptr[i]);
    }
    
    //reallocating array
    printf("enter the new size of array\n");
    scanf("%d",&n);
    ptr=(int*)realloc(ptr,n * sizeof(int));
    for (int i = 0; i < n; i++)
    {
        printf("enter the new id of employee\n");
        scanf("%s",ptr[i]);
    }
    
    for (int i = 0; i < n; i++)
    {
        printf("The new id of employee is %s\n",ptr[i]);
    }

    return 0;
}