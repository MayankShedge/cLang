#include<stdio.h>
#include<string.h>
int main()
{
    char s1[]="mayank";
    char s2[]="yash";
    char s3[54];
     // puts(strcat(s1,s2));  
    //printf("the length of s1 is %d\n and s2 is %d\n",strlen(s1),strlen(s2));
   /* printf("the reverse of s1 is:\n ");
     puts(strrev(s1));*/
    /*strcpy(s3 ,strcat(s1,s2));
    puts(s3);*/
     


    
    return 0;
}