#include <stdio.h>

int main(int argc, char const *argv[])
{
    int a,b;
    printf("Enter number a\n");
    scanf("%d", &a);

    printf("Enter number b\n");
    scanf("%d", &b);

    printf("The Sum is %d\n", a+b);

    return 0;
}