#include<stdio.h>

int main()
{
    int a,b,c,d,e,f;
    printf("enter the first number\n",a);
    scanf("%d", &a);
    printf("enter the second number\n",b);
    scanf("%d", &b);
    c = a + b;
    d = a - b;
    e = a * b;
    f = a / b;

    printf("the sum of 2 numbers is %d\n",c);
    printf("the diff of 2 numbers is %d\n",d);
    printf("the product of 2 numbers is %d\n",e);
    printf("the division of 2 numbers is %d\n",f);

    return 0;
}