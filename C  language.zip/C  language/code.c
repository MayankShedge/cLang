#include <stdio.h>
#include <string.h>

#define MAX_RULES 5
#define MAX_NONTERMS 5
#define MAX_TERMS 5
#define MAX_LENGTH 100

char rules[MAX_RULES][MAX_LENGTH] = {
    "E -> T E'",
    "E' -> + T E' | #",
    "T -> F T'",
    "T' -> * F T' | #",
    "F -> ( E ) | id"
};

char nonterm_userdef[MAX_NONTERMS][MAX_LENGTH] = {"E", "E'", "F", "T", "T'"};
char term_userdef[MAX_TERMS][MAX_LENGTH] = {"id", "+", "*", "(", ")"};

char sample_input_string[MAX_LENGTH] = "id * id + id";

char diction[MAX_NONTERMS][MAX_RULES][MAX_LENGTH];
char firsts[MAX_NONTERMS][MAX_LENGTH];
char follows[MAX_NONTERMS][MAX_LENGTH];

void computeAllFirsts();
void computeAllFollows();
void createParseTable();
char *validateStringUsingStackBuffer(char **parsing_table, int grammarll1, char **table_term_list, char *input_string, char **term_userdef, char *start_symbol);

void main() {
    computeAllFirsts();
    char *start_symbol = nonterm_userdef[0];
    computeAllFollows();
    char *parsing_table[MAX_NONTERMS][MAX_TERMS];
    int result = 1;
    char *tabTerm[MAX_TERMS];

    createParseTable(parsing_table, result, tabTerm);

    if (sample_input_string[0] != '\0') {
        char *validity = validateStringUsingStackBuffer(parsing_table, result, tabTerm, sample_input_string, term_userdef, start_symbol);
        printf("%s", validity);
    } else {
        printf("\nNo input String detected");
    }
}

void computeAllFirsts() {
    // Implementation for computing firsts
}

void computeAllFollows() {
    // Implementation for computing follows
}

void createParseTable(char *parsing_table[MAX_NONTERMS][MAX_TERMS], int grammarll1, char *table_term_list[MAX_TERMS]) {
    // Implementation for creating parsing table
}

char *validateStringUsingStackBuffer(char **parsing_table, int grammarll1, char **table_term_list, char *input_string, char **term_userdef, char *start_symbol) {
    char buffer[MAX_LENGTH], stack[MAX_LENGTH];
    strcpy(buffer, input_string);
    strcpy(stack, start_symbol);
    // Implementation for string validation
}
