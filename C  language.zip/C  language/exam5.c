#include<stdio.h>
int fact(int n)
{
    if (n==0 || n==1)
    {
        return 1;
    }

    else{
        return n*fact(n-1);
    }
    
}

int main()
{
    int n,ans;
    printf("enter the number you want factorial of");
    scanf("%d",&n);
    ans=fact(n);
    printf("the factoirial of number is %d",ans);
    return 0;
}