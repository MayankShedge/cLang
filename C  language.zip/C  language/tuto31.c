#include<stdio.h>
void changevalue(int* address)
{
     *address=999;
    //*address=666;
}
int main()
{
    int a=35, b=44;
    printf("the value of a is %d\n", a);
   // printf("the value of b is %d\n", b);
    changevalue(&a);
    printf("the value of a now is %d\n", a);
   // printf("the value of b now is %d\n", b);
    
    return 0;
}