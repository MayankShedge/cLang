#include<stdio.h>
int main()
{
    char i,j;
    for (char i = 'A'; i < 'E'; i++)
    {
        for (char j = 0; j <= i; j++)
        {
            printf("%c",i);
        }
        
    }
    
    return 0;
}