#include <stdio.h>
int main()
int sum(int a ,int b);
void printstar(int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        printf("%c",'*');
    }
}

{
    int main()
int a,b,c;
a=9;
b=87;
c=sum(a,b);
printstar(7);
return 0;
}