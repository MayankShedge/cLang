#include<stdio.h>
#define  PI 3.14
int main()
{
    float Area;
    int R;
    printf("enter the value of radius\n");
    scanf("%d\n", &R);
    Area =  PI * R *R;
    printf("the area is %f\n", Area);  
    return 0;
}