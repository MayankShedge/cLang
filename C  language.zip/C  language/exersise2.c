#include<stdio.h>

int main()
{
    int a,b,c;
    
    printf("enter your marks\n");

    printf("marks out of 100 are\n");
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);

    if (a>=40)
    {
        printf("\n you have passed in maths and science and your prize is $45",a);
    }

    else if (b>=40)
    {
        printf("\n you have passed in maths and your prize is $15",b);
    }

    else if (c>=40)
    {
        printf("\n you have passed in science and your prize is $15",c);
    }

    else if (a,b,c <=40)
    {
        printf("\n sorry you have not passed any subject better luck next time");
    }


    
    return 0;
}