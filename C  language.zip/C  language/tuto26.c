#include<stdio.h>

int main()
{
    int a=45;
    int* ptra= &a;
    int* ptrb= NULL;
    printf("the value of a is %d\n", *ptra);
    printf("the address of a is %d\n", &ptra);
    printf("the address of a is %d\n", ptra);
    printf("the address of b is %d\n", ptrb);


    
    return 0;
}