#include<stdio.h>
int main()
{
    int arr[10];
    int i,average,sum=0;
    printf("enter the elements of array:-\n");
    for (int i = 0; i < 10; i++)
    {
        printf("the elements are\n");
        scanf("%d",&arr[i]);
    }

    for (int i = 0; i < 10; i++)
    {
        sum+=sum+a[i];
        printf("the sum is %d",sum);
    }
    
    average=sum/10;
    printf("the average is %d",average);
    
    
    return 0;
}