#include<stdio.h>
int len(int n);
int main()
{
    int n;
    int arr[5]={5,20,11,25,45};
    int min=arr[0];
    int length=sizeof(arr);
     for (int i = 0; i < length; i++)
    {
        if (arr[i]<min)
        {
            min=arr[i];
        }
        
    }
    
    //len(int n);
    printf("the smallest element of array is %d",min);
    return 0;
}

/*int len(int n)
{
    for (int i = 0; i < length; i++)
    {
        if (arr[i]<min)
        {
            min=arr[i];
        }
        
    }
    
}*/