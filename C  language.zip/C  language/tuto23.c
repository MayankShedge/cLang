#include<stdio.h>

int main()
{
    int marks[2][4]={4,34,242,366},{3,4,5,6};
    

    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            printf("the marks of %d element of student is %d\n", i,j,marks[i][j]);
        }
        
        
    }
    


    /*marks [0]=34;
    printf("the marks of student 1 are %d\n", marks[0]);

    marks[1]=422;
    printf("the marks of student 2 are %d\n", marks[1]);

    marks[2]=245;
    printf("the marks of student 3 are %d\n", marks[2]);

    marks[3]=4;
    printf("the marks of student 4 are %d\n", marks[3]);*/

    



    
    return 0;
}