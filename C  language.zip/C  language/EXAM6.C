#include<stdio.h>
int main()
{
    char i,j;
    for (char i ='A' ; i<='D'; i++)
    {
        for (char j = 'A'; j<=i; j++)
        {
            printf("%c",i);
        }
        printf("\n");
        
    }

    printf("also for reverse pattern");
    
    for (char i ='D' ; i>='A'; i--)
    {
        for (char j = 'A'; j<=i; j++)
        {
            printf("%c",i);
        }
        printf("\n");
        
    }
 return 0;   
}