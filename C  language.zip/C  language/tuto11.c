#include<stdio.h>

int main()
{
    int age;
    int marks;

    printf("Enter your age\n");
    scanf("%d",&age);

    printf("\n enter your marks");
    scanf("%d",&marks);
    
    switch (age)
    {
    case 3:
        printf("the age is 3\n");
        break;

        case 13:
        printf("the age is 13\n");
        break;

        case 23:
        printf("the age is 23\n");
        break;
        
    default:
    printf("age is not 3,13 or 23\n");
        break;
    }

    switch (marks)
    {
    case 40:
        printf("your marks are 40");
        break;
    
    default:
    printf("your marks are not 40");

        break;
    }

    return 0;
}