#include<stdio.h>
int main()
{
    int a[3][3],b[3][3],c[3][3],i,j;
    printf("enter elements of 1st array:-");
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            printf("the elements of array are [%d][%d]",a[i],a[j]);
            scanf("%d",a[i][j]);
        }
        
    }

    printf("enter elements of 2nd array:-");
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            printf("the elements of array are [%d][%d]",b[i],b[j]);
            scanf("%d",a[i][j]);
        }
        
    }

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
           c[i][j]=a[i][j]+b[i][j];
        }
        
    }

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
           printf("the addition of two programs is:-");
           printf("%d\t",c[i][j]);
        }
      printf("\n");
    }
    return 0;
}