#include<stdio.h>

int main()
{
    char input;
    float KmsTOMiles=0.621371;
    float InchesToFoot=0.0833333;
    float CmsToInches=0.393701;
    float PoundsToKgs=0.453592;
    float InchesToMeters=0.0254;
    float KmperhToMpers=0.2777778;
    float JouleToCalories=0.000239006;
    float first,second;
     
     while (1)
     {
         printf("enter input charecter.q to quit\n 1.km to miles\n 2.inches to foot\n 3.cms to inches\n 4.pounds to kgs\n 5.inches to meters\n 6.km/h to m/s\n 7.joules to calories\n");
         scanf("%c" ,&input);

         switch (input)
         {
         case 'q':
             printf("quit the program");
             goto end;
             break;

         case'1':
         printf("enter quantity in terms of first unit\n");
         scanf("%f" ,&first) ;
         second = first * KmsTOMiles;
         printf("%f kms is equal to %f miles\n", first,second);
         break;  

         case'2':
         printf("enter quantity in terms of first unit\n");
         scanf("%f" ,&first) ;
         second = first * InchesToFoot;
         printf("%f inches is equal to %f foots\n", first,second);
         break;

         case'3':
         printf("enter quantity in terms of first unit\n");
         scanf("%f" ,&first) ;
         second = first * CmsToInches;
         printf("%f cms is equal to %f inches\n", first,second);
         break;

         case'4':
         printf("enter quantity in terms of first unit\n");
         scanf("%f" ,&first) ;
         second = first * PoundsToKgs;
         printf("%f pounds is equal to %f kgs\n", first,second);
         break;

         case'5':
         printf("enter quantity in terms of first unit\n");
         scanf("%f" ,&first) ;
         second = first * InchesToMeters;
         printf("%f inches is equal to %f meters\n", first,second);
         break;

         case'6':
         printf("enter quantity in terms of first unit\n");
         scanf("%f" ,&first) ;
         second = first * KmperhToMpers;
         printf("%f km/h is equal to %f m/s\n", first,second);
         break;

         case'7':
         printf("enter quantity in terms of first unit\n");
         scanf("%f" ,&first) ;
         second = first * JouleToCalories;
         printf("%f joules is equal to %f calories\n", first,second);
         break;
         
         default:
         printf("in default now");
             break;
         }
     }
     

    end:
    return 0;
}