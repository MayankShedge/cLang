#include<stdio.h>
int main()
{
    int a,b,c;
    printf("enter any 3 numbers");
    scanf("%d%d%d",&a,&b,&c);
    if (a==b==c)
    {
        printf("all the three are equal");
    }

    else if(a>b)
    
        
        {
            if(a>c)
            printf("%d number is greatest",a);
        }
        
    

    else if(b>c)
    {
        printf("%d is the greatest",b);
    }

    else
    {
        printf("%d is the greatest",c);
    }
        
    return 0;
}