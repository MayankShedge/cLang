#include<stdio.h>

int main()
{
  int a;
  printf("Enter the integer whose table you want to display\n");
  scanf("%d",&a);
  printf("%d * %d = %d\n%d * %d = %d\n%d * %d = %d\n%d * %d = %d\n"
             "%d * %d = %d\n%d * %d = %d\n%d * %d = %d\n%d * %d = %d\n"
             "%d * %d = %d\n%d * %d = %d\n",a,1,a*1,a,2,a*2,a,3,a*3,a,4,a*4,
             a,5,a*5,a,6,a*6,a,7,a*7,a,8,a*8,a,9,a*9,a,10,a*10);
  
  return 0;
}