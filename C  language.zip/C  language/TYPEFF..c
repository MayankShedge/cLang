#include<stdio.h>
int larele(int array[],int n);
int main()
{
    int arr[]={10,3,8,4,6,250,210};
    int max=larele(arr,7);
    printf("the largest element is %d",max);
    return 0;
}

int larele(int array[],int n)
{
    int max=0;
    for (int i = 0; i < n; i++)
    {
        if (array[i]>max)   
        {
            max=array[i];

        }
        
        return max;
    }
    
}