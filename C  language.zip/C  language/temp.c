#include<stdio.h>
int main()
{
  int temp;
  printf("enter the tempreature\n");
  scanf("%d",&temp);

  if (temp<=0)
  {
      printf("freezing cool");
  }
    else if (temp<=10)
    {
        printf("very cold");
    }

    else if (temp<=20)
    {
        printf("cold");
    }

    else if (temp<=30)
    {
        printf("normal");
    }

    else if (temp<=40)
    {
        printf("hot");
    }

    else if (temp<=50)
    {
        printf("very hot");
    }

    else{
        printf("enter valid tempreature");
    }
    
    return 0;
}