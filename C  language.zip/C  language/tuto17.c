#include <stdio.h>

int main()
{
    label:

    printf("\a we are in a label \n");
    goto end;

    printf("\n hello world");
    goto label;

    end:
    printf("\n we are in the end");

    return 0;
}